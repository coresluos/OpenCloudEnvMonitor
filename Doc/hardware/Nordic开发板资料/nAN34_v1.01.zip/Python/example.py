# Copyright (c) 2013 Nordic Semiconductor. All Rights Reserved.
#
# The information contained herein is property of Nordic Semiconductor ASA.
# Terms and conditions of usage are described in detail in NORDIC
# SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
#
# Licensees are granted free, non-transferable use of the information. NO
# WARRANTY of ANY KIND is provided. This heading must NOT be removed from
# the file.

import dtm

def main():
	#General setup
	setup = dict ()
	setup['TestSerialPortName'] = "COM64"	#DUT (Device Under Test)
	setup['GoldenSerialPortName'] = "COM65"	#Golden sample
	setup['Frequency'] = 1					#Frequency the test should be run on
	setup['Bitpattern'] = dtm.PRBS9			#The bit pattern used for the test. PRBS9, 11110000 (FOUR_ONE_FOUR_ZERO), 10101010 (ONE_ZERO), CONSTANT_CARRIER
	setup['Length'] = 10					#Length of the test package
	setup['Runtime'] = 100					#How long the Receiver should be receiving. In ms
	setup['PERLimit'] = 30					#The packet error limit in percent. Default 30
	
	#Run tests on a single channel
	print "Running tests on channel 1"
	dtmObject = dtm.DTM(setup)
	try:
		dtmObject.runBothRXandTXTests()
	except dtm.DTMError as error:
		print error.errormessage()
		
	print "TX PER: %s%%" % dtmObject.txper
	print "RX PER: %s%%" % dtmObject.rxper
	
	del dtmObject
	
	#Run tests on a series of channels	
	channels = [1, 5, 7, 9]
	txResult = 0
	rxResult = 0
	
	print ""
	print "Running over a series of channels"
	
	for channel in channels:
		setup['Frequency'] = channel
		
		dtmObject = dtm.DTM(setup)
		
		try:
			dtmObject.runBothRXandTXTests()
			txResult = txResult + dtmObject.txper
			rxResult = rxResult + dtmObject.rxper
		except dtm.DTMError as error:
			print error.errormessage()
			txResult = txResult + 100
			rxResult = rxResult + 100

		print "Results for channel: %s" % channel
		print "TX PER: %s%%" % dtmObject.txper
		print "RX PER: %s%%" % dtmObject.rxper
				
		del dtmObject
		
	print "Total result:"
	print "TX PER: %s%%" % (txResult / len(channels))
	print "RX PER: %s%%" % (rxResult / len(channels))
	
	#Run transmitter and receiver tests separately
	dtmObject = dtm.DTM(setup)

	print ""
	print "Running Transmitter and receiver tests separately"
	
	try:
		txper = dtmObject.runTransmitterTest()
		rxper = dtmObject.runReceiverTest()
		
		print "TX PER: %s%%" % txper
		print "RX PER: %s%%" % rxper
	except dtm.DTMError as error:
		print error.errormessage()
		
	

if __name__ == '__main__':
    main()
